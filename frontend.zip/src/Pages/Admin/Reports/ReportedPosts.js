import React, { useState, useEffect } from 'react';
import { Container, Typography, Box, Divider } from '@mui/material';
import axios from 'axios';
import PostReportBox from '../../../Components/Doctor/PostReportBox';

function PostReports() {
  const [reports, setReports] = useState([]);

  useEffect(() => {
    fetchReports();
  }, []);

  const fetchReports = async () => {
    try {
      const response = await axios.get('http://localhost:8000/admins/postreports');
      console.log(response.data.reports);
      setReports(response.data.reports);
    } catch (error) {
      console.error('Error fetching reports:', error);
    }
  };

  return (
    <Container maxWidth="lg">
      <Typography variant="h4" gutterBottom>
        Post Reports
      </Typography>
      {reports.map((report, index) => (
        <React.Fragment key={index}>
            <PostReportBox report={report} />
          {/* <Box
            bgcolor="#756464"
            color="white"
            p={2}
            mt={2}
            borderRadius={4}
          >
            <Typography variant="body1" gutterBottom>
              Reported by: {report.user}
            </Typography>
            <Typography variant="body2" gutterBottom>
              Reason: {report.reason}
            </Typography>
          </Box>
          {index !== reports.length - 1 && <Divider variant="middle" />} */}

        </React.Fragment>
      ))}
    </Container>
  );
}

export default PostReports;

