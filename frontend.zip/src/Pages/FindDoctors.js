import React from 'react'
import MyDoctors from './MyDoctors'
const FindDoctors = () => {
  return (
    <>
        <MyDoctors/>
    </>
  )
}

export default FindDoctors